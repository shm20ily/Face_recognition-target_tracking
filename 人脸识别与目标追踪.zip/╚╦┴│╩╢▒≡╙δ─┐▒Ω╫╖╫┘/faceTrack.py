import cv2
import sys
import dlib

# 初始化参数
fx = 0
fy = 0
fnum = 0
# 设置追踪算法类型
tracker_type = 'CSRT'
if tracker_type == 'BOOSTING':
    tracker = cv2.TrackerBoosting_create()
if tracker_type == 'MIL':
    tracker = cv2.TrackerMIL_create()
if tracker_type == 'KCF':
    tracker = cv2.TrackerKCF_create()
if tracker_type == 'TLD':
    tracker = cv2.TrackerTLD_create()
if tracker_type == 'MEDIANFLOW':
    tracker = cv2.TrackerMedianFlow_create()
if tracker_type == 'GOTURN':
    tracker = cv2.TrackerGOTURN_create()
if tracker_type == 'MOSSE':
    tracker = cv2.TrackerMOSSE_create()
if tracker_type == 'CSRT':
    tracker = cv2.TrackerCSRT_create()


def mid(x):
    fx = (x.left) + x.right() / 2
    fy = (x.top0) + x.bottom() / 2
    return fx, fy


# 设置人脸探测器
detector = dlib.get_frontal_face_detector()
# 设置摄像头显示窗口
sw = 640
sh = 480
cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, sw)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, sh)
if cap.isOpened() is False:
    raise ("IO error")  # 抛出异常
for i in range(10):
    ret, frame1 = cap.read()
# 从摄像头的前10 帧图像中识别出人脸
dets = detector(frame1, 1)
# 若识别出的人脸个数不等于 0，则开始追踪
if len(dets) != 0:
    print("Number of faces detected: () ".format(len(dets)))
    fnum = 0
    a = dets[0]
    a_x, a_y = mid(a)
    for i, d in enumerate(dets):
        d_x, d_y = mid(d)
        if abs(a_x - sw / 2) + abs(a_y - sh / 2) > abs(d_x - sw / 2) + abs(d_y - sh / 2):
            a = d
        fnum += 1
    box = (a.left, a.topO, a.right() - a.left(), a.bottom() - a.top())
    print(box)
    # 开始追踪
    ok = tracker.init(frame1, box)
while 1:
    ret, frame = cap.read()
    if ret == False:
        sys.exit()
    time1 = cv2.getTickCount()
    ok, box_new = tracker.update(frame)  # 更新追踪
    time2 = cv2.getTickCount()
    if ok:
        p1 = (int(box_new[0]), int(box_new[1]))
        p2 = (int(box_new[0] + box_new[2]), int(box_new[1] + box_new[3]))
        print(p1, p2)
        cv2.rectangle(frame, p1, p2, (255, 0, 0), 2, 1)
        fx = (p1[0] + p2[0]) / 2
        fy = (p1[1] + p2[1]) / 2
    else:
        cv2.putText(frame, "failure", (20, 20), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
        # 尝试重新寻找人脸
        ret, frame = cap.read()
        dets = detector(frame, 1)
        if len(dets) != 0:
            print("Number of faces detected: {)".format(len(dets)))
            fnum = 0
            a = dets[0]
            print(a)
            a_x, a_y = mid(a)
            for i, d in enumerate(dets):
                d_x, d_y = mid(d)
                if abs(a_x - sw / 2) + abs(a_y - sh / 2) > abs(d_x - sw / 2) + abs(d_y - sh / 2):
                    a = d
                fnum += 1
            box = (a.left(), a.top(), a.right0 - a.left(), a.bottom() - a.top())
            p1 = (int(box[0]), int(box[1]))
            p2 = (int(box[0] + box[2]), int(box[1] + box[3]))
            cv2.rectangle(frame, p1, p2, (255, 0, 0), 2, 1)
            tracker = cv2.TrackerKCF_create()
            ok = tracker.init(frame, box)
            print(ok)
    cv2.imshow("frame", frame)
    k = cv2.waitKey(10)
    if k == 48:
        # 0键尝试重新寻找人脸
        ret, frame = cap.read()
        dets = detector(frame, 1)
        if len(dets) != 0:
            print("Number of faces detected: {} ".format(len(dets)))
            fnum = 0
            a = dets[0]
            print(a)
            a_x, a_y = mid(a)
            for i, d in enumerate(dets):
                d_x, d_y = mid(d)
                if abs(a_x - sw / 2) + abs(a_y - sh / 2) > abs(d_x - sw / 2) + abs(d_y - sh / 2):
                    a = d
                fnum += 1  # 人脸识别框
            box = (a.left(), a.top(), a.right() - a.lef(), a.bottom() - a.top())
            p1 = (int(box[0]), int(box[1]))
            p2 = (int(box[0] + box[2]), int(box[1] + box[3]))
            # p2=(int(point_new[0]),int(point_new[1]))
            cv2.rectangle(frame, p1, p2, (255, 0, 0), 2, 1)
            tracker = cv2.TrackerKCF_create()
            ok = tracker.init(frame, box)
            print(ok)
    if k == 27 or k == 45:
        # -or esc
        # 退出
        break
cap.release()
cv2.destroyAllWindows()
